package com.neet.DiamondHunter.Application;


import java.awt.image.BufferedImage;
import com.neet.DiamondHunter.TileMap.TileMap;

import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Control {
	
	@FXML GridPane mapGridPane;
	ImageView tile;
	Image tileImage;
	
	private TileMap tileMap;
	private Image image;
	private int rowNum;
	private int colNum;
	//private Graphics2D g = (Graphics2D) image.getGraphics();
	
	public void initialize() {
		
		tileMap = new TileMap(16);
		
		//load map and tiles
		tileMap.loadTiles("/Tilesets/testtileset.gif");
		tileMap.loadMap("/Maps/testmap.map");
		
		//get row and col numbers
		rowNum = tileMap.getNumRows();
		colNum = tileMap.getNumCols();
		
		int i, j;
		for(i = 0; i < rowNum; i++){
			
			for(j = 0; j < colNum; j++){
				
				tile = new ImageView();
				mapGridPane.add(tile, j, i);
				
				tileImage = getTileImage(i, j);
				
				tile.setImage(tileImage);
			}
		}
	}
	
	private Image getTileImage(int row, int col){
		
		int numTilesAcross = tileMap.getNumTilesAcross();
		int rc = tileMap.getIndex(row, col);
		int r = rc / numTilesAcross;
		int c = rc % numTilesAcross;
	
		//convert awt BufferedImage to javafx Image
		Image image = SwingFXUtils.toFXImage(tileMap.getTileImage(r, c), null);
		return image;
		
	}
}
