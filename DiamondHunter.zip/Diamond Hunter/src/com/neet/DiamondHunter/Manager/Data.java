// Global helper class.
// Records finish time upon game completion.

package com.neet.DiamondHunter.Manager;

public class Data {
	
	public static long time;
	
	public static void setTime(long l) { time = l; }
	public static long getTime() { return time; }
	
}
